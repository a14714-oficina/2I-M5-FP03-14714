<?php
require "conexao.php";

$username = "";
$password = "";
$error = "";


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST["nome"];
    $password = $_POST["password"];

    $sql = "SELECT * FROM utilizadores WHERE username = ? AND password = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$username, $password]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        header("Location: ../m5-crud/index.php"); 
        exit;
    } else {
        $error = "Username ou password incorretos.";
        $password = "";
    }
}
?>

<!doctype html>
<html lang="pt">
<head>
<meta charset="utf-8">
<title>Login - Erro</title>
</head>
<body>
<h1>Login sem sucesso!</h1>
<?php if (!empty($error)) {
    echo "<p style='color:red;'>$error</p>";
} ?>
<a href="index.php">Voltar ao login</a>
</body>
</html>