<?php
try {
  $pdo = new PDO("mysql:host=sql202.infinityfree.com;dbname=if0_40156205_modulo5_db;charset=utf8", "if0_40156205", "flm7H0bI9r0QieT");
  $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
  die("Erro na ligação: " . $e->getMessage());
}
?>