<?php
include "conexao.php";
$produto = isset($_POST['produto']) ? trim($_POST['produto']) : '';
$preco = isset($_POST['preco']) ? floatval($_POST['preco']) : 0;
if($produto === '' || $preco < 0){
  header("Location: produtos_lista.php"); exit;
}
$stmt = $pdo->prepare("INSERT INTO produtos (produto, preco) VALUES (?, ?)");
$stmt->execute([$produto, $preco]);
header("Location: produtos_lista.php?ok=1");
exit;